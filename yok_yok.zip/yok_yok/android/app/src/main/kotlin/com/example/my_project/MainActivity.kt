package com.flutterflow.yokyok

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
