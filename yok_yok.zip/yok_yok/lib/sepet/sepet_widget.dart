import '../flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SepetWidget extends StatefulWidget {
  SepetWidget({Key key}) : super(key: key);

  @override
  _SepetWidgetState createState() => _SepetWidgetState();
}

class _SepetWidgetState extends State<SepetWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      body: SafeArea(
        child: ListTile(
          title: Text(
            'Lo',
            style: FlutterFlowTheme.title3.override(
              fontFamily: 'Poppins',
            ),
          ),
          subtitle: Text(
            'Lorem ipsum dolor...',
            style: FlutterFlowTheme.subtitle2.override(
              fontFamily: 'Poppins',
            ),
          ),
          trailing: Icon(
            Icons.arrow_forward_ios,
            color: Color(0xFF303030),
            size: 20,
          ),
          tileColor: Color(0xFFF5F5F5),
          dense: false,
        ),
      ),
    );
  }
}
